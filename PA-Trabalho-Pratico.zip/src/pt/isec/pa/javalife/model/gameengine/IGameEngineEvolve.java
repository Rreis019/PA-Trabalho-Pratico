package pt.isec.pa.javalife.model.gameengine;
public interface IGameEngineEvolve {
 void evolve(IGameEngine gameEngine, long currentTime);
}