package pt.isec.pa.javalife.model.data.elements;

public enum Element {INANIMATE, FLORA, FAUNA}