package pt.isec.pa.javalife.model.data.elements;

import pt.isec.pa.javalife.model.Ecosystem;

public class Animal extends Fauna{

    public Animal(Ecosystem ecosystem, double positionX, double positionY) {
        super(ecosystem, positionX, positionY);
    }



}
