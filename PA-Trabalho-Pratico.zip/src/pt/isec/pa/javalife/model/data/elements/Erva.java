package pt.isec.pa.javalife.model.data.elements;

public class Erva extends Flora{
    public Erva(double positionX, double positionY) {
        super(positionX, positionY);
    }
}
