package pt.isec.pa.javalife.model.data.elements;

public final class Pedra extends Inanimate {
    public Pedra(double positionX, double positionY) {
        super(positionX, positionY);
    }
}