package pt.isec.pa.javalife.model.fsm;

public enum Direction
{
	LEFT,
	RIGHT,
	UP,
	DOWN
};

