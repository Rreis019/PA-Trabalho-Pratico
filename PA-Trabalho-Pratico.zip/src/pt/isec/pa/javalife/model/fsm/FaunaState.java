package pt.isec.pa.javalife.model.fsm;

public enum FaunaState
{
	MOVING,
	SEARCH_FOOD,
	EATING,
	ATTACKING,
	REPRODUCE,
}

